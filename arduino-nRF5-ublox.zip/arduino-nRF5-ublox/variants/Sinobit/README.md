# Sino:Bit support files for Arduino
Contributed by Tomas Lubkowitz @sceptic_int for Sino:Bit 

For LED Matrix functionality please look at https://learn.adafruit.com/sino-bit-with-arduino/dastels-overview


